﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebCoreMvcTemplate.Models
{
    public class Movie
    {
        public int id { get; set; }
        public string MName { get; set; }
        public int MRating { get; set; }
        public string MStar { get; set; }

    }
}
