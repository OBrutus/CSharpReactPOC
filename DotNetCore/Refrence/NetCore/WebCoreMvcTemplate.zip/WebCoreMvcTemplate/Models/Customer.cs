﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebCoreMvcTemplate.Models
{
    public class Customer
    {
        public int id { get; set; }
        public string CustName { get; set; }
        public string City { get; set; }
    }
}
