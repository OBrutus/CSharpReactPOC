﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EkamArtMBProj.Models
{
    public class Painting
    {
        public int id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }

    }
}
