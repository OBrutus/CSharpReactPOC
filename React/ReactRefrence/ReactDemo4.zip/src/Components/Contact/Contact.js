import React, { Fragment } from "react";

//Create component - class

class Contact extends React.Component {
  render() {
    return (
      <div className="jumbotron">
        <h2>Contact us for any queries</h2>
        <h3>Call:123456</h3>
        <h3>Mail us at react@support.com
          
        </h3>
      </div>
    );
  }
}

export default Contact;
