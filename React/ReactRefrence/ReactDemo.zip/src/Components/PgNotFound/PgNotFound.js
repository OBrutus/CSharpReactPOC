import React from "react";

class PgNotFound extends React.Component {
  render() {
    return (
      <div className="jumbotron">
        <h2>Did you jus land on an error page?</h2>
        <h3>Click here to go back</h3>
      </div>
    );
  }
}

export default PgNotFound;
