import React, { Fragment } from "react";

//Create component - class

class Contact extends React.Component {
  render() {
    return (
      // React Fragment
      <>
        <h2> Contact us for any Queries!</h2>
        <h3>Call us at 123345</h3>
      </>
    );
  }
}

export default Contact;
