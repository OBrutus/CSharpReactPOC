import React from "react";

//Component - function
function Home() {
  return (
    <div>
      <h1 className="text-info"> Welcome to EMovies!</h1>
      <p>A One stop destination for all the movie buffs!</p>
    </div>
  );
}

export default Home;
